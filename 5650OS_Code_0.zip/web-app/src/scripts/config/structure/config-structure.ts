﻿export interface ConfigStructure {
    SERVER_URL: string;
    DATE: {
        LONG_FORMAT: string;
        SHORT_FORMAT: string;
    };
};
