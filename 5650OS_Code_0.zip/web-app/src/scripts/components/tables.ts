﻿export * from "./tables/table";
