﻿interface ObjectConstructor {
    assign(target: any, ...sources: any[]): any;
}
