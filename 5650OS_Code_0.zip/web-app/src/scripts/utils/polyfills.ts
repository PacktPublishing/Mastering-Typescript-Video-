﻿import * as es6Promise from "es6-promise";
import "./polyfills/object-assign";

es6Promise.polyfill();
