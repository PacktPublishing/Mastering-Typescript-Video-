﻿export enum FoodItemStatus {
    Active = 0,
    Inactive = 1
}
