﻿export enum OrderStatus {
    Pending = 0,
    Received = 1,
    Enroute = 2,
    Delivered = 3,
    // removed: Lost = 4,
    Canceled = 5
}
