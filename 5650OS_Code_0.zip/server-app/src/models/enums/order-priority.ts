﻿export enum OrderPriority {
    Low = 0,
    Medium = 1,
    High = 2
}
